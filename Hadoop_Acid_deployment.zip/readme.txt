Original project name: Hadoop_Acid
Exported on: 06/20/2017 12:17:03
Exported by: ATTUNITY_LOCAL\Ori.Porat
