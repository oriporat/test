Original project name: Hadoop_Acid
Exported on: 06/20/2017 12:26:20
Exported by: ATTUNITY_LOCAL\Ori.Porat
