Original project name: Hadoop_Acid
Exported on: 06/20/2017 15:11:37
Exported by: ATTUNITY_LOCAL\Ori.Porat
