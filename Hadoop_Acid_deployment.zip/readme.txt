Original project name: Hadoop_Acid
Exported on: 06/20/2017 12:16:47
Exported by: ATTUNITY_LOCAL\Ori.Porat
