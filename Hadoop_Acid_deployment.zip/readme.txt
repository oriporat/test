Original project name: Hadoop_Acid
Exported on: 06/20/2017 15:08:10
Exported by: ATTUNITY_LOCAL\Ori.Porat
