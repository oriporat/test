Original project name: Hadoop_Acid
Exported on: 06/20/2017 15:33:22
Exported by: ATTUNITY_LOCAL\Ori.Porat
