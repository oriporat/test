Original project name: Hadoop_Acid
Exported on: 06/20/2017 17:16:56
Exported by: ATTUNITY_LOCAL\Ori.Porat
